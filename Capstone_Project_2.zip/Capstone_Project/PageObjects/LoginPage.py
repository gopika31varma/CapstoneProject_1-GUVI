#LoginPage.py
#python file to describe all the PageObject datas
from selenium.webdriver.common.by import By

#class login is the locator class with locator details
class login:
    textbox_username_name = 'username'
    textbox_password_name = 'password'
    button_login_xpath = '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button'

    def __init__(self,driver):
        self.driver = driver

    #Action Methods
    def setUserName(self,username):
        self.driver.find_element(by=By.NAME, value=self.textbox_username_name).clear()
        self.driver.find_element(by=By.NAME, value=self.textbox_username_name).send_keys(username)

    def setPassword(self,password):
        self.driver.find_element(by=By.NAME, value=self.textbox_password_name).clear()
        self.driver.find_element(by=By.NAME, value = self.textbox_password_name).send_keys(password)



    def clickLogin(self):
        self.driver.find_element(by=By.XPATH, value=self.button_login_xpath).click()


# Python Class for Selenium locators
class locators:
    pim_xpath = '//*[@id="app"]/div[1]/div[1]/aside/nav/div[2]/ul/li[2]/a'
    add_xpath = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[3]/a'
    add_save_xpath = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[2]/button[2]'
    employee_list_xpath = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/a'
    Emp_SearchByName_xpath = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[2]/div/div/input'
    search_button_xpath= '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[2]'
    Emp_firstname = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/div[2]/input'
    Emp_last_name = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[1]/div[1]/div/div/div[2]/div[3]/div[2]/input'
    Emp_MiddleName = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[1]/div[1]/div/div/div[2]/div[2]/div[2]/input'
    Employee_id_xpath = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div[2]/div[1]/div[2]/div/div/div[2]/input'
    Emp_MiddleName_xpath = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[1]/div[1]/div/div/div[2]/div[2]/div[2]/input'
    Emp_otherId_xpath = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[2]/div[1]/div[2]/div/div[2]/input'
    Save_button_xpath = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[5]/button'
    edit_xpath   = '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[2]/div[1]'
    delete_xpath = "(//button[@type='button'])[5]"
    confirm_delete = '//*[@id="app"]/div[3]/div/div/div/div[3]/button[2]'
    forgot_pwd = '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[4]/p'
    reset_pwd = '//*[@id="app"]/div[1]/div[1]/div/form/div[2]/button[2]'
    cancel_reset = '//*[@id="app"]/div[1]/div[1]/div/form/div[2]/button[1]'
    reset_pwd_link = '//*[text()="Reset Password link sent successfully"]'
    user_management = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[1]/span'
    Org = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[3]/span'
    job = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[2]/span/i'
    qualification = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[4]/span'
    nationality = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[5]/a'
    more = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[6]/span'
    coporate_banking = '//*[@id="app"]/div[1]/div[1]/header/div[2]/nav/ul/li[6]/ul/div[1]/li'
    config = '//*[text()="Configuration "]'
    admin = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[1]'
    PIM = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[2]'
    leave = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[3]'
    time_xpath = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[4]'
    recruitment = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[5]'
    My_info = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[6]'
    performance = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[7]'
    dashboard = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[8]'
    directory = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[9]'
    maintanance = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[10]'
    buzz = '(//span[@class="oxd-text oxd-text--span oxd-main-menu-item--name"])[11]'

