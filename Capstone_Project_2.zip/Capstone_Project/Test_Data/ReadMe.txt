

This is a Project that automates login and Employee Details Edit Features of an Application called OrangeHRM. Below are the features that are Automated:
1. Login with username and password
2. Invalid Login using wrong password
3. Add Employee details in PIM
4. Edit Employee details
5. Delete Employee Details

Test Cases Details:
1. Test_login.py - validates successful login with username and password
2. Test_PIM.py - validated adding,deleting and editing employee details
3. Forgot_password.py - validates the use case of Forgot password criteria
4. Test_PIM_2.py - validates if header options are displayed or not in Admin page
5. Test_PIM_3.py - validates menu options are displayed or not
6. Test_PIM_4.py - validates page launch successful or not


Required Packages:
1. Selenium
2. Selinium-webdriver
3. pytest
4. pytest-html
5. time

To Generate Reports Use the below Commands:

1. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Reports_login.html .\Test_Cases\Test_login.py
2. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Reports_PIM.html .\Test_Cases\Test_PIM.py
3. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Forgot_password.html .\Test_Cases\Forgot_password.py
4. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Test_PIM_2.html .\Test_Cases\Test_PIM_2.py
5. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Test_PIM_3.html .\Test_Cases\Test_PIM_3.py
6. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Test_PIM_4.html .\Test_Cases\Test_PIM_4.py
