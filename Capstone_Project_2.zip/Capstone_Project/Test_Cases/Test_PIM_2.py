#Test_PIM_2.py

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
import pytest
from PageObjects.LoginPage import login
from PageObjects.LoginPage import locators
#Test Cases to work with PIM locator
class Test_PIM_02:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'
    password = 'admin123'

    # Test Cases to verify header options are displayed or not in Admin page
    def test_header(self):

        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        self.driver.maximize_window()

        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            assert True
            print("Login Successfull")
        else:
            assert False
            print("Login not Successfull")
        sleep(5)
        self.driver.find_element(by=By.LINK_TEXT, value="Admin").click()
        sleep(5)
        if (self.driver.find_element(by=By.XPATH,value=locators.user_management).is_displayed()):
            assert True
            print("user management present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.job).is_displayed()):
            assert True
            print("job present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.qualification).is_displayed()):
            assert True
            print("qualification present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.Org).is_displayed()):
            assert True
            print("Organisation present")
        else:
            assert False

        if (self.driver.find_element(by=By.LINK_TEXT,value="Nationalities").is_displayed()):
            assert True
            print("nationality present")
        else:
            assert False

        if (self.driver.find_element(by=By.LINK_TEXT, value="Corporate Branding").is_displayed()):
            assert True
            print("Corporate Branding  present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH, value=locators.config).is_displayed()):
            assert True
            print("Configuration present")
        else:
            assert False

