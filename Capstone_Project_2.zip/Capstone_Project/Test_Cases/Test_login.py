#Test_login.py
#Test Cases for Login Feature
#Import all required packages
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from time import sleep
import pytest
from PageObjects.LoginPage import login

#Test Case 1 to Ensure Suuccessfull Login
class Test_001_login:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'
    password = 'admin123'

    #Test Case  to verify if the hompage is launched correctly
    def test_homepage_title(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            assert True
            print("Page launch successfull")
        else:
            assert False

    #Test case to Verify if login is successfull with correct login ID and password
    def test_login(self):

        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)

        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            assert True
            print("Login Successfull")
        else:
            assert False
            print("Login not Successfull")
#Test Case to verify if login fails and gives invalid credentials warning with incorrect login details
#Username is correct but password is wrong
class Test_002_Invalid_login:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'
    password = 'kjdlwhf'


    def test_login(self):

        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)

        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        sleep(5)
        if(self.driver.find_element(by=By.XPATH, value= '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/div/div[1]/div[1]/p').is_displayed()):
            assert True
            print("INVALID CREDENTIALS")
        else:
            assert False



