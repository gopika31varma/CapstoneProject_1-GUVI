from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
import pytest
from PageObjects.LoginPage import login
from PageObjects.LoginPage import locators

#Test Case 1 to Ensure Suuccessfull Login
class Test_001_test_Pwd_reset_successfull:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'



    def test_Pwd_reset_successfull(self):

        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)

        self.lp = login(self.driver)
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.forgot_pwd).click()
        sleep(5)
        self.lp.setUserName(self.username)
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.reset_pwd).click()
        sleep(5)
        if (self.driver.find_element(by=By.XPATH,value=locators.reset_pwd_link).is_displayed()):
            assert True
            print("PASSWORD RESET LINK SENT SUCCESSFULLY")
            self.driver.close()
        else:
            assert False
            print("PASSWORD RESET LINK NOT SENT")
            self.driver.close()


class Test_002_test_Pwd_reset_not_successfull:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'

    def test_Pwd_reset_successfull(self):

        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)

        self.lp = login(self.driver)
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.forgot_pwd).click()
        sleep(5)
        self.lp.setUserName(self.username)
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.cancel_reset).click()
        sleep(5)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            assert True
            print("Password reset cancelled")
            self.driver.close()
        else:
            assert False
            self.driver.close()







