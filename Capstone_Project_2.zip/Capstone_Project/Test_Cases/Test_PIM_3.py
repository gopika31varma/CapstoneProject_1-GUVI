#Test_PIM_3
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
import pytest
from PageObjects.LoginPage import login
from PageObjects.LoginPage import locators
#Test Cases to work with PIM locator

class Test_PIM_01:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'
    password = 'admin123'

   #Test Case to verify menu options are displayed or not
    def test_menu_options(self):

        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        self.driver.maximize_window()

        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            assert True
            print("Login Successfull")
        else:
            assert False
            print("Login not Successfull")
        sleep(5)
        self.driver.find_element(by=By.LINK_TEXT, value="Admin").click()
        sleep(5)
        if (self.driver.find_element(by=By.XPATH,value=locators.admin).is_displayed()):
            assert True
            print("Admin present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.PIM).is_displayed()):
            assert True
            print("PIM present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.leave).is_displayed()):
            assert True
            print("Leave present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.time_xpath).is_displayed()):
            assert True
            print("Time present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.recruitment).is_displayed()):
            assert True
            print("recruitment present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.My_info).is_displayed()):
            assert True
            print("My_info present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.performance).is_displayed()):
            assert True
            print("performance present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.dashboard).is_displayed()):
            assert True
            print("dashboard present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.directory).is_displayed()):
            assert True
            print("directory present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.maintanance).is_displayed()):
            assert True
            print("maintanance present")
        else:
            assert False

        if (self.driver.find_element(by=By.XPATH,value=locators.buzz).is_displayed()):
            assert True
            print("buzz present")
        else:
            assert False

