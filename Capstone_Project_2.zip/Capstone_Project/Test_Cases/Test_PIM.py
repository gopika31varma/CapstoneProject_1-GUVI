#Test_PIM.py

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
import pytest
from PageObjects.LoginPage import login
from PageObjects.LoginPage import locators
#Test Cases to work with PIM locator
class Test_PIM:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'
    password = 'admin123'

    Emp_search = "Gopika"
    EmpMidName1 = "K"
    EmpMidName2 = "Rahul"
    Emp_lastName = 'Varma'
    EmpId = "2890"
    Emp_OtherID = "85525"

   #Test Case to add Employee details
    def test_PIM_AddEmpDetails(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Page launch successfull")
        else:
            print("Page launch not successfull")
        sleep(5)
        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Login Successfull")
        else:
            print("Page launch not successfull")

        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.pim_xpath).click()
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.add_xpath).click()
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_firstname).send_keys(self.Emp_search)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_MiddleName).send_keys(self.EmpMidName1)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_last_name).send_keys(self.Emp_lastName)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Employee_id_xpath).send_keys(Keys.CONTROL, "a")
        self.driver.find_element(by=By.XPATH, value=locators.Employee_id_xpath).send_keys(Keys.DELETE)
        self.driver.find_element(by=By.XPATH, value=locators.Employee_id_xpath).send_keys(self.EmpId)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.add_save_xpath).click()
        sleep(2)
        self.driver.close()

    #Test Case to Search the given employee name and edit the middle name and OtherID details
    def test_PIM_EditEmpDetails(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Page launch successfull")
        else:
            print("Page launch not successfull")
        sleep(5)
        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        sleep(2)
        self.driver.maximize_window()
        sleep(2)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Login Successfull")
        else:
            print("Page launch not successfull")

        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.pim_xpath).click()
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.employee_list_xpath).click()
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_SearchByName_xpath).send_keys(self.Emp_search)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.search_button_xpath).click()
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.edit_xpath).click()
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_MiddleName_xpath).send_keys(Keys.CONTROL, "a")
        self.driver.find_element(by=By.XPATH, value=locators.Emp_MiddleName_xpath).send_keys(Keys.DELETE)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_MiddleName_xpath).send_keys(self.EmpMidName2)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_otherId_xpath).send_keys(Keys.CONTROL, "a")
        self.driver.find_element(by=By.XPATH, value=locators.Emp_otherId_xpath).send_keys(Keys.DELETE)
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_otherId_xpath).send_keys(self.Emp_OtherID)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.Save_button_xpath).click()
        sleep(2)
        self.driver.close()
        print("\n SUCCESSFULLY ADDED EMPLOYEE MIDDLE NAME and Other ID")

    #Test Case to search the given employee by name and delete the employe details
    def test_PIM_DeleteEmpDetails(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Page launch successfull")
        else:
            print("Page launch not successfull")
        sleep(5)
        self.lp = login(self.driver)
        sleep(5)
        self.lp.setUserName(self.username)
        self.lp.setPassword(self.password)
        self.lp.clickLogin()
        sleep(2)
        self.driver.maximize_window()
        sleep(2)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Login Successfull")
        else:
            print("Page launch not successfull")

        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.pim_xpath).click()
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.employee_list_xpath).click()
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.Emp_SearchByName_xpath).send_keys(self.Emp_search)
        sleep(2)
        self.driver.find_element(by=By.XPATH, value=locators.search_button_xpath).click()
        sleep(8)
        self.driver.find_element(by=By.XPATH, value=locators.delete_xpath).click()
        sleep(5)
        self.driver.find_element(by=By.XPATH, value=locators.confirm_delete).click()
        sleep(5)
        print("Delete successfull")







