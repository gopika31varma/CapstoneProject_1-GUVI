#Test_PIM_4.py

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.common.action_chains import ActionChains
import pytest
from PageObjects.LoginPage import login
from PageObjects.LoginPage import locators
#Test Cases to work with PIM locator
class Test_PIM_02:
    base_url = 'https://opensource-demo.orangehrmlive.com/web/index.php/auth/login'
    username = 'Admin'
    password = 'admin123'

   #Test Case to verify page launch
    def test_PIM_launch(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        self.driver.get(self.base_url)
        act_title = self.driver.title
        if act_title == "OrangeHRM":
            print("Page launch successfull")

        else:
            print("Page launch not successfull")
        sleep(5)
        self.driver.close()