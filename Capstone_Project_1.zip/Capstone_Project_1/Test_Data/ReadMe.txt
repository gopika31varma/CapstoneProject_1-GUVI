

This is a Project that automates login and Employee Details Edit Features of an Application called OrangeHRM. Below are the features that are Automated:
1. Login with username and password
2. Invalid Login using wrong password
3. Add Employee details in PIM
4. Edit Employee details
5. Delete Employee Details


Required Packages:
1. Selenium
2. Selinium-webdriver
3. pytest
4. pytest-html
5. time

To Generate Reports Use the below Commands:

1. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Reports_login.html .\Test_Cases\Test_login.py
2. pytest -v -s --capture=sys --html=C:\Users\SESA689090\Documents\Capstone_Project_1\Reports\Reports_PIM.html .\Test_Cases\Test_PIM.py
